% GSPBOX - Startup   
%    
%  Start
%    gsp_start         -  Lauch the toolbox
%    gsp_make          -  Compile the toolbox
%    gsp_install       -  Install the 3rdparty software and try to compile souces
%    gsp_install_unlocbox -  Install the UNLocBoX
%
%  For help, bug reports, suggestions etc. please send email to
%  gspbox 'dash' support 'at' groupes 'dot' epfl 'dot' ch
%

