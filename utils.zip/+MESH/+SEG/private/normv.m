function nn = normv(v)
nn = sqrt(sum(v.^2,2));