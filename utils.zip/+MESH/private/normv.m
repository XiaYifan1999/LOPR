function nn = normv(V)
nn = sqrt(sum(V.^2,2));
end
