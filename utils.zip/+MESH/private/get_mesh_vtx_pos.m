function X = get_mesh_vtx_pos(S)
    X = [S.surface.X, S.surface.Y, S.surface.Z];
end